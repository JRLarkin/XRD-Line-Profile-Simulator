#!/bin/bash

# This deletes ALL histogram folders and files in directory!!

echo WARNING: 'This will delete all histograms in this directory! Continue (y/n)?'
read contvar

if [ $contvar == y ]
then
	joblist='job_list.txt'
	njobs=`wc ${joblist} | awk '{print $1}'`
	jobvar=0
	cwd=`pwd`
	for ((i=1 ; i <= ${njobs} ; i++ )); do
	folder=`awk '(NR=='${i}'){print}' ${joblist}`
	rm -r $folder
	done
	rm job_list.txt
	echo -e "\nAll histogram folders and contents erased.\n"
else
	echo Cancelled.
fi

