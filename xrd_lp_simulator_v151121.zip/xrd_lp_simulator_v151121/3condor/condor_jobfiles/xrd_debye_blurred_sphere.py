import os
import sys

import numpy as np
from scipy.special import erfc
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('input_file', type=str)
parser.add_argument('output_folder', type=str)
parser.add_argument('index_0', type=int)
parser.add_argument('index_1', type=int)
parser.add_argument('n_bins', type=int)
parser.add_argument('R0', type=float)
parser.add_argument('DR', type=float)

args = parser.parse_args()

def lammps_dump_to_ppd(dump_cell):
    """Take a supercell as specified in a lammps dump file and convert to three edge vectors of a parallelipiped"""
    xy = dump_cell[0,2]; xz = dump_cell[1,2]; yz = dump_cell[2,2]
    xlo = dump_cell[0,0] - min(0.0, xy, xz, xy+xz)
    xhi = dump_cell[0,1] - max(0.0, xy, xz, xy+xz)
    ylo = dump_cell[1,0] - min(0.0, yz)
    yhi = dump_cell[1,1] - max(0.0, yz)
    zlo = dump_cell[2,0]
    zhi = dump_cell[2,1]
    ppd = np.array([
        [xhi-xlo, 0.0, 0.0],
        [xy, yhi-ylo, 0.0],
        [xz, yz, zhi-zlo]
    ])
    return ppd

def read_lammps_dump(file):
    """Read a lammps dump file and return the number of atoms, the supercell specification and a subset of atom data"""
    # Gets number of atoms; searces for ITEM: ATOMS line and begins from next line, returns number of lines.
    f = open(file)
    found_line = False
    for l, line in enumerate(f):
        words = line.split()
        if (len(words)>3 and words[3] == 'ATOMS' and found_line == False):
            lineIndex = l
            found_line = True
    f.close()
    f = open(file)
    for s in range(lineIndex+1):
        f.readline()
    num_atoms = int(f.readline().split()[0])
    f.close()

    # Get supercell shape: Finds ITEM: BOX BOUNDS line, returns dimensions from next 3 lines.
    f = open(file)
    found_line = False
    for l, line in enumerate(f):
        words = line.split()
        if (len(words)>1 and words[1] == 'BOX' and found_line == False):
            lineIndex = l
            found_line = True
    f.close()
    supercell_shape = np.zeros((3,3), dtype=float)
    f = open(file)
    for s in range(lineIndex+1):
        f.readline()
    for s in range(3):
        words = f.readline().split()
        n_words = len(words)
        supercell_shape[s,:n_words] = words
    f.close()
    supercell = lammps_dump_to_ppd(supercell_shape)

    # Get atom data
    f = open(file)
    found_line = False
    for l, line in enumerate(f):
        words = line.split()
        if (len(words)>1 and words[1] == 'ATOMS' and found_line == False):
            lineIndex = l
            found_line = True
    f.close()
    f = open(file)
    for s in range(lineIndex):
        f.readline()
    words = f.readline().split()
    fields = 5
    x_in = None; y_in = None; z_in = None; type_in = None; pe_in = None
    for s in range(len(words)):
        if words[s] == 'x':
            x_in = s-2
        elif words[s] == 'y':
            y_in = s-2
        elif words[s] == 'z':
            z_in = s-2
        elif words[s] == 'type':
            type_in = s-2
        elif words[s] == 'c_peatom':
            pe_in = s-2
    atom_data = np.zeros((num_atoms,fields), dtype=float)
    for s in range(num_atoms):
        words = f.readline().split()
        if x_in is not None:
            atom_data[s,0] = words[x_in]
        if y_in is not None:
            atom_data[s,1] = words[y_in]
        if z_in is not None:
            atom_data[s,2] = words[z_in]
        if type_in is not None:
            atom_data[s,3] = words[type_in]
        if pe_in is not None:
            atom_data[s,4] = words[pe_in]
    f.close()
    return num_atoms, supercell, atom_data

output_file = args.output_folder + '/histogram_' + str(args.index_0) + '-' + str(args.index_1) + '.txt'

num_atoms, cell, r = read_lammps_dump(args.input_file)

# assign weights to the atoms to implement a grain size distribution
com = np.mean(r[:,:3],axis=0)
R = np.linalg.norm(r[:,:3]-com, axis=1)
w = erfc((R-args.R0)/args.DR)

r_max = np.round(np.linalg.norm(np.max(cell,axis=0)-np.min(cell,axis=0))/1.0) + 1.0 # This needed changing when no PBC
bins = np.linspace(0,r_max,args.n_bins+1)

#test_vecs = np.zeros((3,3), dtype=float)
#for s in range(3):
#    test_vecs[s,:] = np.cross(cell[(s+1)%3,:],cell[(s+2)%3,:])
#    test_vecs[s,:] = test_vecs[s,:]/np.dot(cell[s,:],test_vecs[s,:])

cume_hist = np.zeros(args.n_bins, dtype=int)
for i in range(args.index_0,args.index_1):
    dr = r[i+1:,:3] - r[i,:3] 
    #for s in range(3):
    #    dr = dr + np.einsum('i,j->ij', -np.round(np.dot(dr,test_vecs[s,:])), cell[s,:])
    d = np.linalg.norm(dr, axis=1)
    hist, bin_edges = np.histogram(d, bins, weights=np.minimum(w[i+1:],w[i]))
    cume_hist = cume_hist + hist

f = open(output_file, 'w')
for j in range(args.n_bins):
    f.write(str(bins[j]) + ' ' + str(cume_hist[j]) + '\n')
f.close()



