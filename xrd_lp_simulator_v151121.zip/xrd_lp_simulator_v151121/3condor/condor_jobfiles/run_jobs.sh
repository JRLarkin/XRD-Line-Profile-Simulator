#!/bin/bash
joblist='job_list.txt'
njobs=`wc ${joblist} | awk '{print $1}'`

cwd=`pwd`
for ((i=1 ; i <= ${njobs} ; i++ )); do
	folder=`awk '(NR=='${i}'){print}' ${joblist}`
	echo $folder
	cd ${folder}
	#condor_submit -a concurrency_limits=THROTTLE50 submit.txt
	condor_submit submit.txt
	cd ${cwd}
done

