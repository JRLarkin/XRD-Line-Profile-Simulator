import os
import sys
import numpy as np

f = open('job_list.txt', 'r')

make_total = True
for line in f:
    folder = line.split('/')[0]
    hist_file = folder + '/' + folder + '.txt'
    if os.path.exists(hist_file):
        hist = np.loadtxt(hist_file)
        print(hist_file)
        if make_total:
            total_histogram = np.copy(hist)
            make_total = False
        else:
            total_histogram[:,1] = total_histogram[:,1] + hist[:,1]
f.close()

np.savetxt('histogram_total.txt', total_histogram)