#!/bin/bash

# syntax: ./resubmit.sh jobid '0000000' -- where number is first atom number in histogram name (e.g. 1550000 in histogram_1550000-1600000)

jobid=$1
min=$2
let "max=$2 + 50000"
dir=histogram_"$min"-"$max"'/'
echo $dir

condor_rm $jobid
cd $dir
condor_submit submit.txt
cd ..
echo "Script for $dir has been resubmitted"
