#!/bin/bash
joblist='job_list.txt'
njobs=`wc ${joblist} | awk '{print $1}'`
jobvar=0
jobtot=0

cwd=`pwd`
for ((i=1 ; i <= ${njobs} ; i++ )); do
	folder=`awk '(NR=='${i}'){print}' ${joblist}`
	cd ${folder}
	if ! [[ -n "$(find -name 'out.txt')" ]]
	then
		echo "out.txt not found in $folder"
		let "jobvar++"
		let "jobtot++"
	else
		let "jobtot++"
	fi
	cd ${cwd}
done
echo -e "\nCheck finished. Found $jobvar/$jobtot omissions.\n"

