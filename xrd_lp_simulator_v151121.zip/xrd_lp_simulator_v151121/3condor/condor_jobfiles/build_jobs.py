import os
import sys
import numpy as np
from shutil import copyfile

# The script_file is the code that will be run on the condor pool for each job
script_file = 'xrd_debye_blurred_sphere.py'
# The next line points at the dump file containing the structure
input_file = 'relaxed.min'
# The next two lines are a hacky way of determining the number of atoms in the file based on the number of lines!
n_atoms = -9
for line in open(input_file): n_atoms += 1

n_bins = 200000  # Number of bins to use for the pairwise separation histogram (a large number is fine, it gives fine resolution without slowing things down)
R0 = 180  # The mean radius of the spheres of crystal to consider
DR = 40  # The spread (std dev) in sphere radii to consider

n_per_job = 50000  # Number of atoms to give to each processor to handle, folowed by arithmetic to work out how many porcessors will be needed
n_jobs = np.int(n_atoms/n_per_job)
if n_atoms > n_per_job*n_jobs:
    n_jobs = n_jobs + 1

bounds = np.linspace(0,n_per_job*n_jobs,n_jobs+1).astype(int)
bounds[-1] = n_atoms

f = open('job_list.txt', 'w') # File that will contain the list of jobs to run

# The loop below creates folders for each job, and in each folder produces the submit script for a condor job and copies in the python script_file
for s in range(n_jobs):
    #for s in range(2):
    folder = 'histogram_' + str(bounds[s]) + '-' + str(bounds[s+1]) + '/'
    output_file = 'histogram_' + str(bounds[s]) + '-' + str(bounds[s+1]) + '.txt'
    f.write(folder + '\n')
    os.makedirs(folder)
    
    # Submit file
    fs = open(folder+'submit.txt', 'w')
    fs.write('Universe = vanilla\n')
    #fs.write('Requirements = (OpSys == "LINUX" && Arch == "X86_64")\n')
    fs.write('Requirements = (OpSys == "LINUX" && Arch == "X86_64" && HAS_PYTHON_3_4=?=True)\n')
    fs.write('Executable = /opt/anaconda/envs/py34/bin/python\n')
    fs.write('Transfer_Executable = False\n')
    fs.write('Arguments = ' + script_file + ' ' + input_file + ' ' + './' + ' ' + str(bounds[s]) + ' ' + str(bounds[s+1]) + ' ' + str(n_bins) + ' ' + str(R0) + ' ' + str(DR) + '\n')
    fs.write('Environment = PYTHONHOME=/opt/anaconda/envs/py34\n')
    fs.write('transfer_input_files = ../' + input_file + ',' + script_file + '\n')
    #fs.write('transfer_output_files = ../' + output_file + '\n')
    fs.write('log = log.txt\n')
    fs.write('Output = out.txt\n')
    fs.write('Error = err.txt\n')
    fs.write('Notification = never\n')
    fs.write('Request_Memory = 1024\n')
    
    fs.write('Should_Transfer_Files = Yes\n')
    fs.write('When_to_transfer_output = on_exit\n')
    fs.write('Queue\n')
    fs.close()

    # Python script
    copyfile(script_file, folder + script_file)

f.close()

