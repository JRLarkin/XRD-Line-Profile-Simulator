import numpy as np
import matplotlib.pyplot as plt
import os
import argparse

# GitBash Input Syntax: python calculate_profile.py 'path to input file'

parser = argparse.ArgumentParser()
parser.add_argument('input_file', type=str)
args = parser.parse_args()

## CALCULATE DEBYE SCATTERING ##
def xrd_profile(data, Qmin=1.0, Qmax=10.0, nQ=10000):
    dbin =(data[1,0]-data[0,0])
    Qbins = np.linspace(Qmin,Qmax,nQ+1)

    profile = np.zeros((nQ,2), dtype=float)
    profile[:,0] = 0.5*(Qbins[:-1]+Qbins[1:])
    for i in range(nQ):
        profile[i,1] = np.sum(data[:,1] * np.sin(profile[i,0]*(data[:,0] + dbin)) / (profile[i,0]*(data[:,0] + dbin)))
    profile[:,1] = profile[:,1] /np.sum(data[:,1])
    return profile

# SAVE TO FILE ##
file = str(args.input_file)

data = np.loadtxt(file)
profile = xrd_profile(data)
np.savetxt(file.replace('histogram','profile'), profile)